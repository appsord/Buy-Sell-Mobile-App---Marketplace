#import <Flutter/Flutter.h>

@interface RateMyAppPlugin : NSObject<FlutterPlugin>
@end
