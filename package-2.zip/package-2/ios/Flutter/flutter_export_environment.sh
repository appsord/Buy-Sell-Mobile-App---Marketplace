#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/tarunbardawa/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/tarunbardawa/FlutterApps/Flutter-BuySell(v__2.7)/Mobile Source/Flutter-BuySell"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=/Users/tarunbardawa/FlutterApps/Flutter-BuySell(v__2.7)/Mobile Source/Flutter-BuySell/lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=2.7.0"
export "FLUTTER_BUILD_NUMBER=22"
export "DART_DEFINES=RkxVVFRFUl9XRUJfQVVUT19ERVRFQ1Q9dHJ1ZQ=="
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=/Users/tarunbardawa/FlutterApps/Flutter-BuySell(v__2.7)/Mobile Source/Flutter-BuySell/.dart_tool/package_config.json"
