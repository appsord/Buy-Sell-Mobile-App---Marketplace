---
name: Bug report
about: Create a report to help us improve

---

<!-- Before opening an issue please read the documentation https://sh1d0w.github.io/multi_image_picker/ -->

**Bug Report**

`multi_image_picker` version: <!-- Insert multi_image_picker library version here  -->

Is it happening on Android: <!-- Yes / No -->

Is it happening on iOS: <!-- Yes / No -->

```
 <!-- run `flutter doctor` and paste the output here: -->
```

**Describe the bug**

A clear and concise description of what the bug is.

