#import <Flutter/Flutter.h>

@interface MultiImagePickerPlugin : NSObject<FlutterPlugin>
@end
