# CHANGE LOG

## 1.0.1

- Update local_storage dependency to latest 0.5.0
- Added and fixed linter rules
- Fixed default Dark mode problem from PRs
